import { Component } from '@angular/core';

@Component({
  selector: 'app-page-users',
  imports: [],
  templateUrl: './page-users.html',
  styleUrl: './page-users.css'
})
export class PageUsers {

}
