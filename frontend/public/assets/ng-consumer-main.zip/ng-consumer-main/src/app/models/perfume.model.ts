export interface Perfume {
    id:number,
    nome:string,
    marca:string,
    nacionalidade:string,
    img:string,
    preco:number
}